from flask import Flask, render_template, request
import callDatabase

app = Flask(__name__)


@app.route('/form')
def form():
    return render_template('form.html')


@app.route('/form2')
def form2():
    return render_template('form2.html')


@app.route('/data/', methods=['POST', 'GET'])
def data():
    if request.method == 'GET':
        return f"The URL /data is accessed directly. Try going to '/form' to submit form"
    if request.method == 'POST':
        form_data = request.form.to_dict()

        make = form_data.get("Make")
        model = form_data.get("Model")

        output = callDatabase.display(make, model)

        #Do the database call here with the make and model variables and put results into a dictionary named "form_data"
        #Can make a different file and do a function call to make it cleaner

        #return render_template('data.html', form_data=form_data)
        return render_template('data.html', form_data=output)


@app.route('/data2/', methods=['POST', 'GET'])
def data2():
    if request.method == 'GET':
        return f"The URL /data is accessed directly. Try going to '/form2' to submit form"
    if request.method == 'POST':
        form_data = request.form.to_dict()

        Begin_Date = form_data.get("Begin")
        End_Date = form_data.get("End")
        city = form_data.get("City")
        state = form_data.get("State")

        output = callDatabase.display2(Begin_Date, End_Date, city, state)

        #print(Begin_Date, End_Date, city, state)

        #Do the database call here with the make and model variables and put results into a dictionary named "form_data"
        #Can make a different file and do a function call to make it cleaner

        return render_template('data2.html', form_data=output)


app.run(host='localhost', port=5000)