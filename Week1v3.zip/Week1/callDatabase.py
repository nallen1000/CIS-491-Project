import sqlite3 as sql

global connection
global cursor

connection = sql.connect('aircraftDB', check_same_thread=False)
cursor = connection.cursor()


def display(make, model):
    input = (make,model)
    cursor.execute("SELECT * FROM aircraft where acft_make = ? AND acft_model = ?;", input)
    result = cursor.fetchall()

    print(result)
    return result

