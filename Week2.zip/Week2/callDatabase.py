import sqlite3 as sql

global connection
global cursor

connection = sql.connect('aircraftDB', check_same_thread=False)
cursor = connection.cursor()


def display(make, model):
    input = (model,make)
    #cursor.execute("SELECT * FROM aircraft where acft_make = ? AND acft_model = ?;", input)
    #result = cursor.fetchall()

    #print(result)
    #return result

    output = {}

    output['Make'] = [make]
    output['Model'] = [model]

    cursor.execute("""SELECT DISTINCT engines.eng_type FROM engines
                          INNER JOIN aircraft ON aircraft.ev_id = engines.ev_id
                          WHERE aircraft.acft_model = ? AND aircraft.acft_make = ?;""", input)
    result = cursor.fetchall()
    result = [i for sub in result for i in sub]
    output['Engine Type'] = result

    cursor.execute("""SELECT inj_person_count FROM injury
                        INNER JOIN aircraft on aircraft.ev_id = injury.ev_id
                        WHERE acft_model = ? AND acft_make = ? AND injury_level = 'FATL';""", input)
    result = cursor.fetchall()
    result = [i for sub in result for i in sub]
    result = sum(result)
    output['Injury Count'] = [result]

    cursor.execute("""SELECT DISTINCT ev_state FROM events
                        INNER JOIN aircraft on aircraft.ev_id = events.ev_id
                        WHERE acft_model = ? AND acft_make = ?;""", input)
    result = cursor.fetchall()
    result = [i for sub in result for i in sub]
    output['Event State'] = result

    cursor.execute("""SELECT ev_date FROM events
                        INNER JOIN aircraft on aircraft.ev_id = events.ev_id
                        WHERE acft_model = ? AND acft_make = ?;""", input)
    result = cursor.fetchall()
    result = [i for sub in result for i in sub]
    output['Event Date'] = result

    cursor.execute("""SELECT DISTINCT eng_mfgr FROM engines
                        INNER JOIN aircraft on aircraft.ev_id = engines.ev_id
                        WHERE acft_model = ? AND acft_make = ?;""", input)
    result = cursor.fetchall()
    result = [i for sub in result for i in sub]
    output['Engine Manufacturer'] = result

    print(output)
    return output


def display2(Begin_Date, End_Date, city, state):
    input = (Begin_Date, End_Date, city, state)

    output = {}
    output['Begin_Date'] = [Begin_Date]
    output['End_Date'] = [End_Date]
    output['City'] = [city]
    output['State'] = [state]

    #cursor.execute("SELECT * FROM events WHERE ev_city = ? AND ev_state = ?;", input)
    cursor.execute("""SELECT acft_make, acft_model, ev_city, ev_state, ev_date FROM events, aircraft WHERE julianday(ev_date) BETWEEN 
                    julianday(?) AND julianday(?) AND ev_city = ? AND ev_state = ? AND events.ev_id = aircraft.ev_id;""", input)

    result = cursor.fetchall()
    result = [i for sub in result for i in sub]
    output['data'] = result
    #result = [i for sub in result for i in sub]

    print(output)
    return output
